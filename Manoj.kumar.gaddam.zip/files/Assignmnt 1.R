#libraries used:
library(rjson)
library(XML)
library(stringr)
library(plyr)

#function to do address Profiling

address_profiling <- function(address) {
  address_parsed = htmlTreeParse(address, useInternal = TRUE)
  #Parsing the HTML tags using HTML parser.
  addr =  unlist(xpathApply(address_parsed,'//address', xmlValue))
  a = addr
  return(a)
}

#function to find city names

city_name = function(Profiled_addr) {
  if(is.null(Profiled_addr)){
    return("NA")
  }
  citynme_ext = strsplit(Profiled_addr,split = ",")
  name_vect = c(do.call("cbind", citynme_ext))
  city_nm = name_vect[length(name_vect)]
  return (city_nm)
}

# function to check whether the city belongs to USA

country_check = function(city_nme) {
  check = unlist(strsplit(city_nme,split = " "))
  if(is.element(check[1],state.abb)) {
    a = "United States"
    print (a)
  }else {
    a = city_nme
  }
  return(a)
}

city_name_modified = function(Profiled_addr) {
  if(is.null(Profiled_addr)){
    return("NA")
    
    
  }
  citynme_ext = strsplit(Profiled_addr,split = ",")
  name_vect = c(do.call("cbind", citynme_ext))
  city_nm = name_vect[length(name_vect) - 1]
  return (city_nm)
  
  
}



# command to list all the files present in the folder json(dataset)

file_list = list.files("C:/Users/manoj/Downloads/TripAdvisorJson.tar/TripAdvisorJson/json")


#creating a dataframe to store the required fields
dframe1 <- data.frame(H_id = numeric(0),H_name = character(0),price = character(0),address = character(0),stringsAsFactors = FALSE)
colnames(dframe1) = c("H_id","H_name", "price","address")

#loading data into R

for (i in file_list)
{ 
  Raw_data <- fromJSON(paste(readLines(paste("C:/Users/manoj/Downloads/TripAdvisorJson.tar/TripAdvisorJson/json\\",i,sep = "")),collapse = ""))
  price = unlist(Raw_data$HotelInfo['Price'])
  H_name = unlist(Raw_data$HotelInfo['Name'])
  H_id = unlist(Raw_data$HotelInfo['HotelID'])
  address = unlist(Raw_data$HotelInfo['Address'])
  if(is.null(H_name)){
    H_name = "NA"
  }
  if(is.null(H_id)){
    H_id = "NA"
  }
  if(is.null(price)){
    price = "NA"
  }
  if(is.null(address)){
    address = "NA"
  }
  dframe1[nrow(dframe1)+1,] <- c(H_id,H_name,price,address)  
}

dframe1$adr_profiled = lapply(dframe1$address,address_profiling)
#Dropping the unused column
dframe1$address = NULL
dframe1$city = lapply(dframe1$adr_profiled,city_name)
dframe1$city = str_trim(dframe1$city)
dframe1$country = lapply(dframe1$city,country_check)

dframe1$city = NULL

dframe1$city = lapply(dframe1$adr_profiled,city_name_modified)

dframe1$adr_profiled<-as.character(dframe1$adr_profiled)
dframe1$country<-as.character(dframe1$country)
dframe1$city<-as.character(dframe1$city)

#writing data into file

write.csv(dframe1, file = "Projectds.csv",row.names = FALSE)
y<-unique(dframe1$city)
# There are 1806 different cities

write.csv(y, file = "cities.csv",row.names = FALSE)
z<-subset(dframe1,country=='United States')
l<-unique(z$city)
#there are 30 us cities

write.csv(l, file = "uscities.csv",row.names = FALSE)


a<-count(dframe1$city)
b<-subset(a,freq>=30)
write.csv(a, file = "ass.3.csv",row.names = FALSE)
write.csv(b, file = "m30.csv",row.names = FALSE)



